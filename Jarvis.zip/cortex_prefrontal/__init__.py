"""
cortex_prefrontal - Module de traitement LLM
"""

from .llm_client import JarvisLLM

__all__ = ['JarvisLLM']